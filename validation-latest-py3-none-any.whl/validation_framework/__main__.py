from validation_framework import entrypoint

if __name__ == '__main__':
    entrypoint()
