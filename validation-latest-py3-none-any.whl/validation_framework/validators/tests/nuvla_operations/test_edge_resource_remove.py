"""

"""
from validators import ValidationBase


class TestEdgeResourceRemove(ValidationBase):

    def test_resource_removal(self):
        ...
