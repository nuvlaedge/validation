"""

"""
from validation_framework.validators import ValidationBase
from . import validator


# @validator('ConnectivityLoss')
class TestConnectivityLoss(ValidationBase):

    def test_connectivity_loss(self):
        ...
