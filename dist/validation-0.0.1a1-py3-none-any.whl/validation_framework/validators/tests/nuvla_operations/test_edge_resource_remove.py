"""

"""
from validators import ValidationBase
from validators.tests import validator


@validator('')
class TestEdgeResourceRemove(ValidationBase):

    def test_resource_removal(self):
        ...
